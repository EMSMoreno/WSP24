﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class FormVerForm : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adapter;
        DataTable dt;

        public FormVerForm()
        {
            InitializeComponent();
        }
        private void FormVerForm_Load(object sender, EventArgs e)
        {
            LoadBooks();
            AddDeleteButtonColumn();
        }

        private void LoadBooks()
        {
            try
            {
                using (con = new SqlConnection(cs))
                {
                    con.Open();
                    string query = @"
                SELECT 
                    ISBN, 
                    Titulo, 
                    Data_Lancamento, 
                    Sinopse, 
                    Edicao, 
                    Editora, 
                    Idioma, 
                    Numero_Paginas, 
                    Estado, 
                    Codigo_Estante, 
                    Quantidade 
                FROM Livro";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar Livros: " + ex.Message);
            }
        }

        private void DeleteLivro(int rowIndex)
        {
            try
            {
                using (con = new SqlConnection(cs))
                {
                    con.Open();
                    string isbn = dataGridView1.Rows[rowIndex].Cells["ISBN"].Value.ToString();
                    string query = "DELETE FROM Livro WHERE ISBN = @ISBN";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@ISBN", isbn);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Book deleted successfully!");
                    LoadBooks(); // Calls method to reload books
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error deleting this book: " + ex.Message);
            }
        }

        private void AddDeleteButtonColumn()
        {
            DataGridViewButtonColumn btnDeleteColumn = new DataGridViewButtonColumn();
            btnDeleteColumn.HeaderText = "Delete Option";
            btnDeleteColumn.Name = "btnDelete";
            btnDeleteColumn.Text = "Delete";
            btnDeleteColumn.UseColumnTextForButtonValue = true;

            dataGridView1.Columns.Add(btnDeleteColumn);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView1.Columns["btnDelete"].Index && e.RowIndex >= 0)
            {
                var confirmResult = MessageBox.Show("Are you sure you want to delete this book?",
                                                     "Confirm Delete",
                                                     MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                    DeleteLivro(e.RowIndex);
                }
            }
        }
    }
}
