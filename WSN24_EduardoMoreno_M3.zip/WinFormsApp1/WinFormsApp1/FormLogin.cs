﻿using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using WSN24_EduardoMoreno_M3;

namespace WinFormsApp1
{
    public partial class FormLogin : Form
    {
        public class User
        {
            public int ID { get; set; }
            public string Nome { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
        }

        string cs = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;

        #region Password Methods

        public static string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        #endregion

        private bool CreateUser(string email, string password)
        {
            // Cria o hash da senha com SHA-256
            string hashedPassword = HashPassword(password);

            // Insere o novo usuário no banco de dados
            string connectionString = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "INSERT INTO Users (email, Password, failed_login_attempts, is_locked) VALUES (@Email, @Password, 0, 0)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", hashedPassword);
                        cmd.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while creating user: " + ex.Message);
                return false;
            }
        }

        public FormLogin()
        {
            InitializeComponent();
        }

        #region Create User Methods

        private void btnCreateUser_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword2.Text.Trim();

            if (string.IsNullOrWhiteSpace(firstName))
            {
                MessageBox.Show("First name is required.");
                return;
            }
            if (string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Last name is required.");
                return;
            }
            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Email is required.");
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Password is required.");
                return;
            }

            if (!IsValidPassword(password))
            {
                MessageBox.Show("Password must be at least 8 characters long and contain uppercase letters, lowercase letters, numbers, and special characters.");
                return;
            }

            // Cria o hash da senha com SHA-256
            string hashedPassword = HashPassword(password);

            // Dados padrões para o novo usuário
            string role = "Other";  // Role padrão
            bool isLocked = false; // Conta não bloqueada
            int failedLoginAttempts = 0; // Tentativas de login falhadas

            // Armazena o usuário no banco de dados
            if (AddUserToDatabase(firstName, lastName, email, hashedPassword, role, isLocked, failedLoginAttempts))
            {
                MessageBox.Show("User added successfully!");
                ClearFieldsCreateUser();
            }
            else
            {
                MessageBox.Show("Error adding user.");
            }
        }

        private bool IsValidPassword(string password)
        {
            return password.Length >= 8 &&
                   password.Any(char.IsUpper) &&
                   password.Any(char.IsLower) &&
                   password.Any(char.IsDigit) &&
                   password.Any(c => !char.IsLetterOrDigit(c));
        }

        private bool AddUserToDatabase(string firstName, string lastName, string email, string password, string role, bool isLocked, int failedLoginAttempts)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "INSERT INTO Users (first_name, last_name, email, password, role, is_locked, failed_login_attempts) " +
                                   "VALUES (@FirstName, @LastName, @Email, @Password, @Role, @IsLocked, @FailedLoginAttempts)";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@FirstName", firstName);
                        cmd.Parameters.AddWithValue("@LastName", lastName);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);
                        cmd.Parameters.AddWithValue("@Role", role);
                        cmd.Parameters.AddWithValue("@IsLocked", isLocked);
                        cmd.Parameters.AddWithValue("@FailedLoginAttempts", failedLoginAttempts);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        #endregion

        #region Login Methods

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Fill all fields.");
                return;
            }

            if (LoginUser(email, password))
            {
                MessageBox.Show("Login successfully! Welcome to EraMedieval4all!");
                this.Hide();
                ClearFieldsLoginUser();
                new Dashboard().Show();
            }
            else
            {
                MessageBox.Show("Username or password invalid.");
            }
        }

        private bool LoginUser(string email, string password)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT password, failed_login_attempts, is_locked FROM Users WHERE email = @Email";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string storedPassword = reader["password"].ToString();
                                int failedLoginAttempts = Convert.ToInt32(reader["failed_login_attempts"]);
                                bool isLocked = Convert.ToBoolean(reader["is_locked"]);

                                if (isLocked)
                                {
                                    // If the account is blocked, it shows the blocked account form
                                    MessageBox.Show("Your account is locked due to multiple failed login attempts.");
                                    FormBlockedUser blockedUserForm = new FormBlockedUser();
                                    blockedUserForm.ShowDialog(); // Displays the blocked account form
                                    return false;
                                }

                                if (storedPassword == HashPassword(password))
                                {
                                    ResetFailedLoginAttempts(email);
                                    return true;
                                }
                                else
                                {
                                    IncrementFailedLoginAttempts(email, failedLoginAttempts);
                                    return false;
                                }
                            }
                            else
                            {
                                MessageBox.Show("User Not Found.");
                                return false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
                return false;
            }
        }

        private void IncrementFailedLoginAttempts(string email, int failedLoginAttempts)
        {
            failedLoginAttempts++;

            string connectionString = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    bool isLocked = failedLoginAttempts >= 3;
                    string query = "UPDATE Users SET failed_login_attempts = @FailedLoginAttempts, is_locked = @IsLocked WHERE email = @Email";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@FailedLoginAttempts", failedLoginAttempts);
                        cmd.Parameters.AddWithValue("@IsLocked", isLocked);
                        cmd.Parameters.AddWithValue("@Email", email);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void ResetFailedLoginAttempts(string email)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "UPDATE Users SET failed_login_attempts = 0 WHERE email = @Email";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        #endregion

        private void ClearFieldsCreateUser()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            txtPassword2.Clear();
        }

        private void ClearFieldsLoginUser()
        {
            txtUsername.Clear();
            txtPassword.Clear();
        }

        private void btnCleanFormCreate_Click(object sender, EventArgs e)
        {
            ClearFieldsCreateUser();
        }

        private void btnClearFormLogin_Click(object sender, EventArgs e)
        {
            ClearFieldsLoginUser();
        }
    }
}
